package com.example.projetorodrigobossosenhas;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // criando os parametros de texto e imagem
    private TextView textView;
    private ImageView imageView;


   // criando os parametros de deitura usando o finger poit menager
    private FingerprintManager fingerprintManager;
    private FingerprintManager.AuthenticationCallback authenticationCallback;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layautr);
        // reescrevendo a view de uso
        textView = findViewById(R.id.textView);
        imageView = findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.imagem1);


        fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
        authenticationCallback = new FingerprintManager.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                textView.setText("ERROR");
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(MainActivity.this, "Tente novamente ocorreu um ERRO", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
                textView.setText("HELP");
                super.onAuthenticationHelp(helpCode, helpString);
            }

            @Override
            public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
                textView.setText("SUCCESS");
                textView.setTextColor(getResources().getColor(R.color.green, null));
                imageView.setImageResource(R.drawable.imagem3c);
                super.onAuthenticationSucceeded(result);
                Toast.makeText(MainActivity.this, "Login realizado com Sucesso", Toast.LENGTH_SHORT).show();
                open2tela();

            }

            @Override
            public void onAuthenticationFailed() {
                textView.setText("FAILED");
                textView.setTextColor(getResources().getColor(R.color.red, null));
                imageView.setImageResource(R.drawable.imagem2e);
                super.onAuthenticationFailed();
                Toast.makeText(MainActivity.this, "Tente novamente ocorreu uma Falha", Toast.LENGTH_LONG).show();
            }
        };


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void scanButton(View view){
        Toast.makeText(MainActivity.this, "Escaneie o seu dedo", Toast.LENGTH_LONG).show();
        fingerprintManager.authenticate(null, null, 0, authenticationCallback ,null );
     }
// metodo que chama a segunda tela
    public void open2tela(){
        Intent intent = new Intent(this,SegundaOpcaoTeal.class);
        startActivity(intent);

    }


}
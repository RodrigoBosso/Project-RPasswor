
package com.example.projetorodrigobossosenhas;


import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaCadastros extends AppCompatActivity {

    public EditText textoNOME;
    public EditText textoSENHA;

    public  Button b1 ;

   private  SQLiteDatabase tabelabanco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastros);

        b1 = findViewById(R.id.button_Salvar);
        textoNOME = findViewById(R.id.editTextName);
        textoSENHA = findViewById(R.id.editTextPassword);


        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                cadastrar();

            }
        });

    }

    public void cadastrar(){
        if(!TextUtils.isEmpty(textoNOME.getText().toString()) && !TextUtils.isEmpty(textoSENHA.getText().toString())){
             try {
                   //abrindo o banco novamente
                    tabelabanco = openOrCreateDatabase("senhapp" , MODE_PRIVATE, null);

                    String sql = "INSERT INTO registro (nome, senha) VALUES (?,?)";

                    SQLiteStatement stmt = tabelabanco.compileStatement(sql);

                    stmt.bindString(1,textoNOME.getText().toString());
                    stmt.bindString(2,textoSENHA.getText().toString());

                    stmt.executeInsert();

                   tabelabanco.close();

                 Toast.makeText(TelaCadastros.this, "Incrmento realizado realizada", Toast.LENGTH_SHORT).show();
                 finish();

             }catch (Exception e){
                 e.printStackTrace();
             }

        }else{

            Toast.makeText(TelaCadastros.this, "Coloque um Nome e uma Senha", Toast.LENGTH_SHORT).show();

        }
    }


}

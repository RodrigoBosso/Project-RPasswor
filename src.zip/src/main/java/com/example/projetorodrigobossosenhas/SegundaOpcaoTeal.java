package com.example.projetorodrigobossosenhas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SegundaOpcaoTeal extends AppCompatActivity {


    // criando variavél para criar o banco de dados na MainActivity
    private SQLiteDatabase tabelabanco;

    public ListView listViewdados;

    public Button botaocriar;

    //Arrays de Id e Senhas para manipulacão da tabela do Banco
    public ArrayList<Integer> arrayIds;
    public ArrayList<String> arraySenha;

    // Variavél para auxilio de exclusão e manipulação
    public Integer IdSelecionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_opcao_teal);
        //  chama a criação o Banco de dados que vai ser usado nas demais activitis

        listViewdados = (ListView) findViewById(R.id.listViewnomesenha);

        botaocriar = (Button) findViewById(R.id.button_Cadastrar);

        //listener do Botão de criação
        botaocriar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTelaCadastro();
            }
        });


        // Funão de Long Click da Vew voltada para a exclusão do modelo:
        listViewdados.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                IdSelecionado =arrayIds.get(i);
                confirmarExcluir();
                return true;
            }
        });

        // Função Click que possibilita verificar a senha cadastrada:
        listViewdados.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                IdSelecionado =arrayIds.get(i);
                mostrarsenha();
            }
        });

        // cria o banco na primeira vez que é chamado ,e nas demais vezes ele só abre o banco
        // guardado internamente
        criarTabelabanco();

        // lista os dados na activyty
        listardados();

    }


    // Criando o banco de dados ( quando executado pela primeira vez ele cria a tabela , depois ele apenas mantém a tabela criada)
    public void criarTabelabanco(){

        try {
            tabelabanco = openOrCreateDatabase( "senhapp" , MODE_PRIVATE, null);
            tabelabanco.execSQL("CREATE TABLE IF NOT EXISTS registro("+
                    "id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ",nome VARCHAR " +
                    ",senha VARCHAR)");
            tabelabanco.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    public void listardados(){
        try {
           // iniciando os Arrays
            arrayIds = new ArrayList<>();
            arraySenha = new ArrayList<>();

            //abrindo o banco novamente
            tabelabanco = openOrCreateDatabase("senhapp" , MODE_PRIVATE, null);

            // criação do cursor
            Cursor meuCursor = tabelabanco.rawQuery("SELECT id, nome,senha FROM registro ", null);
            // adaptando o resultado para a consulta para o adaptador que vai escrever na tela
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter adaptador = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linhas
            );

            listViewdados.setAdapter(adaptador);
            meuCursor.moveToFirst();
            // imprime os Nomes ta consulta enquanto o resultado não vor nulo
            //como o dado se linhas.add está recebendo 1 que seria a posição 2 da tabela ,já que a é os Ids e o 2 são as Senhas
            while(meuCursor!=null){
                linhas.add(meuCursor.getString(1));
                arrayIds.add(meuCursor.getInt(0));
                arraySenha.add(meuCursor.getString(2));
                meuCursor.moveToNext();
            }
            tabelabanco.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    // metodo que chama a s tela de cadastros
    public void openTelaCadastro() {
        Intent intent = new Intent(this, TelaCadastros.class);
        startActivity(intent);
    }

// quando voltar para essa tela pelo petodo de retorno ela vai ser atializada por padrão através do on Resume
    @Override
    protected void onResume(){
        super.onResume();
        listardados();

    }


    // Metodo de exclusão de dados no Banco de dados:
    public void excluir(){
        try {
            tabelabanco = openOrCreateDatabase("senhapp" , MODE_PRIVATE, null);

            String sql = "DELETE FROM registro WHERE id = ?";
            SQLiteStatement stmt = tabelabanco.compileStatement(sql);
            stmt.bindLong(1,IdSelecionado);
            stmt.executeUpdateDelete();
            listardados();

            tabelabanco.close();
        } catch (Exception e){
            e.printStackTrace();
        }


    }

    public void confirmarExcluir(){
        AlertDialog.Builder msgBox = new AlertDialog.Builder( SegundaOpcaoTeal.this);
        msgBox.setTitle("Excluir");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você deseja excluir esse registro?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
               certeza();
            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.show();

    }

    public void certeza(){
        AlertDialog.Builder msgBox = new AlertDialog.Builder( SegundaOpcaoTeal.this);
        msgBox.setTitle("Certeza?");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você tem certeza que voce realmente deseja excluir esse registro?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                excluir();
                listardados();
                Toast.makeText(SegundaOpcaoTeal.this, "Dados excluidos", Toast.LENGTH_LONG).show();

            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.show();

    }

// Função que mostra a senha correspondente ao nome selecionado através deu uma Box de dialogo
    public void mostrarsenha() {

        try {
            tabelabanco = openOrCreateDatabase("senhapp", MODE_PRIVATE, null);

            // criação do cursor 1 que vai guardar o nome na 1º posição e a senha na segunda posição que foi selecionado
            Cursor meuCursor1 = tabelabanco.rawQuery("SELECT nome , senha FROM registro WHERE id=" + IdSelecionado.toString(), null);
            meuCursor1.moveToFirst();


            AlertDialog.Builder msgBoxSENHA = new AlertDialog.Builder(SegundaOpcaoTeal.this);
            msgBoxSENHA.setTitle("Senha de " + meuCursor1.getString(0)+" :");
            msgBoxSENHA.setMessage(meuCursor1.getString(1));

            msgBoxSENHA.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    //só fecha a mensage BOX
                }
            });
            msgBoxSENHA.show();


            tabelabanco.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}












